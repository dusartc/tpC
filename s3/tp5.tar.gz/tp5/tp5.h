#include <stddef.h>
#include <stdlib.h>
#include <fcntl.h>
int traiter(int f, int *car, int *mot, int *lig);
