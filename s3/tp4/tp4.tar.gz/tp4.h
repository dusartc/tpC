char * miroir (const char *s);
char * saisie ();
